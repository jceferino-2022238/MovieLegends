window.onload = function() {
    // Get the main element
    var mainElement = document.querySelector('main');
  
    // Apply animation class to main element
    mainElement.classList.add('animation');
  };
  window.onload = function() {
    // Get the main element
    var mainElement = document.querySelector('main');
  
    // Apply animation class to main element
    mainElement.classList.add('animation');
  };